export class signup {
    id: number;
    name: string;
  }